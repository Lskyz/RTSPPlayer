//
//  RTSPPlayerApp.swift
//  RTSPPlayer
//
//  Created by 이근용 on 2025/09/15.
//

import SwiftUI

@main
struct RTSPPlayerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
